import os
import json
import boto3
import base64
import time

BUCKET = os.environ['BUCKET']
s3 = boto3.client('s3')

def lambda_handler(event, context):
   #print(event)
   face = event['records'][0]['data']
   print("message from iot: ",face)
   payload = base64.b64decode(face)
   print("decode payload from iot", payload)
   
   json_str = payload.decode('utf8').replace("'", '"')
   json_str = payload.decode('utf8').replace("\n", '')
   json_payload = json.loads(json_str)
   print("json payload: ",json_payload)
   image = json_payload['face']
   faceDecode = base64.b64decode(image)
   
   nowtime = time.strftime("%Y%m%d-%H%M%S")
   file_name = 'face-'+ nowtime + '.jpg'
   folder = 'images/'
   uploadPath = folder + file_name
   response = s3.put_object(Body=faceDecode, Bucket=BUCKET, Key= uploadPath)
   print(response)
   
   return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
   }
