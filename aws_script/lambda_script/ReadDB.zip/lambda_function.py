import json
import boto3
import os

client = boto3.client('dynamodb')
TABLE = os.environ['TABLE']

def lambda_handler(event, context):
    # TODO implement
    
    response = client.scan(
        TableName= TABLE,
        AttributesToGet=['name', 'timestamp']
        )
    
    data = response['Items']
    print(data)
    
    return {
        'statusCode': 200,
        'body': data
    }
