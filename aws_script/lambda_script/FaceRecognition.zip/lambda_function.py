import os
import boto3
import base64
import time
import json
import hashlib
import uuid
from datetime import datetime, timedelta

REGION="us-east-1"
THRESHOLD=80

COLLECTION = os.environ['COLLECTION']
BUCKET = os.environ['BUCKET']
#BATCH_TABLE = os.environ['BATCH_TABLE']
face_table =  os.environ['FACE_TABLE']
STREAM_RECORD = os.environ['STREAM_RECORD']

rekognition = boto3.client("rekognition", REGION)
dynamodb = boto3.resource('dynamodb')
#firehose = boto3.resource('firehose')
s3 = boto3.client('s3')

#batch_table = dynamodb.Table(BATCH_TABLE)
face_table = dynamodb.Table(face_table)
stream_record = dynamodb.Table(STREAM_RECORD)
timeZone = 8

collections = rekognition.list_collections()['CollectionIds'] 
print(collections)

if COLLECTION not in  collections :
    rekognition.create_collection(CollectionId=COLLECTION)

# get time
def getTimestamp():
    # get timestamp
    timestamp = str(datetime.now() + timedelta(hours=timeZone))
    return timestamp

def putFaceIndex(face_id,link,name):
    face_table.put_item(
    Item={
        'face_id': face_id,
        'link': link,
        'name': name,
        'timestamp': str(getTimestamp())
    })
    return None
    
def putFaceRecord(face_id, name):
    random_id = str(uuid.uuid4())
    stream_record.put_item(
    Item={
        'id': random_id,
        'image_id':face_id,
        'name': name,
        'timestamp': str(getTimestamp())
    })
    return None

def lambda_handler(event, context):
    print(event)
    key = event['Records'][0]['s3']['object']['key']

    response = rekognition.search_faces_by_image(
		Image={
			"S3Object": {
				"Bucket": BUCKET,
				"Name": key
			}
		},
        CollectionId=COLLECTION
    )

    print("search_faces_by_image", response)
    
    if 'FaceMatches' in response and response['FaceMatches']:
        best = response['FaceMatches'][0]
        for match in response['FaceMatches']:
            if match['Similarity'] > best['Similarity']:
                best = match
        
        face_id = best['Face']['FaceId']
    else:
        response = rekognition.index_faces(
            Image={
                "S3Object": {
                    "Bucket": BUCKET,
                    "Name": key,
                }
            },
            CollectionId=COLLECTION
        )
        face_id = response['FaceRecords'][0]['Face']['FaceId']
        
    

    try:
        response = face_table.get_item(Key={'face_id': face_id})
        name = response['Item']['name'] 
        
    except KeyError:
        name = "unknown"
        link = 's3://' + BUCKET + '/' + key
        putFaceIndex(face_id, link, name)
        print("Index new face: ", face_id[-5:])
    
    putFaceRecord(face_id,name)
    print("Face result: " ,name)
    
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
