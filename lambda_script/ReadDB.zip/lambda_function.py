import json
import boto3
import os

client = boto3.client('dynamodb')
TABLE = os.environ['TABLE']

def lambda_handler(event, context):
    # TODO implement
    
    response = client.scan(
        TableName= TABLE,
        AttributesToGet=['name', 'timestamp']
        )
    
    data = response['Items']
    
    return {
        'statusCode': 200,
        'body': json.dumps(data),
        'headers': {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Credentials": True
        }
    }
