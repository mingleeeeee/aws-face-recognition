import json
import boto3


client = boto3.client('dynamodb')

def lambda_handler(event, context):
    # TODO implement
    
    response = client.scan(
        TableName= 'stream_record',
        AttributesToGet=['name', 'timestamp']
        )
    
    data = response['Items']
    print(data)
    
    return {
        'statusCode': 200,
        'body': data
    }
